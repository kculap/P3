import * as React from 'react';
import { Text, View, StyleSheet, Button, Alert } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
    <View style={styles.header}>
    <Text style={styles.title}>Title</Text>
    </View>

    <View style ={styles.jumbotron}>
    <View style={styles.left}>
    <Text>Left</Text>
    </View>
    
    <View style={styles.right}>
    <Text>Right</Text>
    </View>
    </View>

    <Button title ="Button" onPress={()=> alert
    ("Button pressed")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
   // justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  title:{
   fontSize: 50,
   fontWeight: "bold",
   textAlign: "center",
   fontFamily: "Arial",
   color: "lightblue"
  },

  jumbotron:{
flexDirection: "row"

  },
  left:{
    backgroundColor: "blue",
    padding:10,
    margin:10,
    borderBotoomWidth:10 
  }
});
