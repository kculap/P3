import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  ActivityIndicator,
  FlatList,
  Image,
  ScrollView,
} from 'react-native';

export function DetailsScreen({ route, navigation }) {
  const [data, setData] = useState([]);
  const [isLoading, setLoading] = useState([]);

  function handleHomePress() {
    navigation.navigate('Home');
  }
  const getData = async () => {
    try {
      const response = await fetch('https://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline');
      const json = await response.json();
      setData(json);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <View>
        {isLoading ? (
          <ActivityIndicator />
        ) : (
          <FlatList
            data={data}
            keyExtractor={({ id }, index) => id}
            renderItem={({ item }) => (
              <View style={styles.wrap}>
                <View style={styles.wrapper}>
    
                  <View>
                    <Image
                      style={styles.image}
                      source={{ uri: `${item.image_link}` }}
                    />
                  </View>
                  <View style={styles.txt}>
                    <Text style={styles.item}>{item.name}</Text>
                    <Text style={styles.itemDescription}>Description:</Text>
                    <Text style={styles.txt}>{item.description}</Text>
                    <View style={styles.itemWrapper}>
                    <Text style={styles.itemDescription}>Brand:</Text>
                     
                      <Text style={styles.item}>
                        {item.brand}
                      </Text>
                    </View>
                    <View style={styles.itemWrapper}>
                    <Text style={styles.itemDescription}>Product type:</Text>
                     
                      <Text style={styles.item}>
                        {item.product_type}
                      </Text>
                    </View>
                     <Text style={styles.itemDescription}>Price:<Text style={styles.item}> {item.price}
                      </Text></Text>
                      
                      <Text style={styles.itemDescription}> Rating:<Text style={styles.itemName}>{item.rating}
                      </Text></Text>
                      
                  </View>
                  
                </View>
              </View>
            )}
          />
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d17683',
  },
  itemName: {
    color: '#d17683',
    fontSize: 20,
    fontWeight: 'bold',
    flexWrap: 'wrap',
  },
  image: {
    width: 100,
    height: 100,
    paddingLeft: 10,
    borderRadius: 20,
  },
  wrap: {
    padding: 20,
  },
  wrapper: {
    flexDirection: 'row',
  },
  item: {
    fontSize: 16,
    fontStyle: 'bold',
    paddingLeft: 5,
  },
  itemDescription: {
    fontSize: 16,
    fontStyle: 'italic',
    color: '#d17683',
  },
  itemWrapper: {
    flexDirection: 'row',
  },

  txt:{
    marginLeft:10,
    backgroundColor: '#FCFAFA',
    borderRadius: 10,
    padding: 5,
    flex: 1, 
    flexWrap: 'wrap',
  }
});
