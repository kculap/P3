import React, { useEffect, useState } from 'react';
import {
  View,
  Image,
  Text,
  Button,
  StyleSheet,
  TextInput,
  FlatList,
} from 'react-native';

export function HomeScreen({ route, navigation }) {
 const [name, setName] = useState("");
 const [surname, setSurname] = useState("");
 const [number, setNumber] = useState("");
 const [email, setEmail] = useState("");
 const [password, setPassword] = useState("");
 const [passwordAgain, setPasswordAgain] = useState("")

  const sendRequest = async () => {
    try {
      await fetch('https://webhook.site/ef1cb80c-c606-45f3-a188-31ef6f2ab31e', {
        method: 'post',
        mode: 'no-core',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: name,
          surname: surname,
          email: email,
          number: number,
          password: password,
          passwordAgain: passwordAgain,
        }),
      });
     setName("");
     setSurname("");
     setNumber("");
     setEmail("");
     setPassword("");
     setPasswordAgain("");
    } catch (error) {}
  };

  function handleSettingsPress() {
    navigation.navigate('Settings');
  }

  return (
    <View style={styles.screen}>
    <Text style={styles.header}>Sign up to continue.</Text>
      <View style={styles.firstSection}>
        <View>
        <Text style={styles.text}>First name </Text>
        <TextInput style={styles.firstInput} value={name} onChangeText={setName}/>
      </View>
        <View>

          <View>
        <Text style={styles.text}>Last name </Text>
        <TextInput style={styles.firstInput} value={surname} onChangeText={setSurname}/>
      </View>
          <View style={styles.inputWrapper}>
           
          </View>
          
        </View>
        
      </View>
        
      <View>
        <Text style={styles.text}>Email address </Text>
        <TextInput style={styles.input} value={email} onChangeText={setEmail} placeholder="email@example.com"/>
      </View>
<View>
        <Text style={styles.text}>Phone number </Text>
        <TextInput style={styles.input} value={number} onChangeText={setNumber}/>
      </View>

<View>
        <Text style={styles.text}>Password </Text>
        <TextInput style={styles.input} value={password} onChangeText={setPassword} secureTextEntry={true} placeholder="●●●●●●●●●●●"/>
      </View>
      <View>
        <Text style={styles.text}>Verify password </Text>
        <TextInput style={styles.input} value={passwordAgain} onChangeText={setPasswordAgain} placeholder="Repeat your password" secureTextEntry={true}/>
      </View>
      <Button title="SIGN UP" onPress={sendRequest} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: "#151f42",
    //justifyContent: "center",
  },
  firstSection: {
    flexDirection: 'row',
  },

  
  inputWrapper: {
    alignItems: 'center',
    flexDirection: 'row',
  },
 firstInput: {
height: 30,
    width: 120,
    borderWidth: 2,
    borderRadius: 8,
    marginBottom: 12,
    backgroundColor :"#384b8f",
    borderColor: "#4258a8",
    margin: 5
 },

  input: {
    height: 30,
    width: 250,
    borderWidth: 2,
    backgroundColor :"#384b8f",
    borderColor: "#4258a8",
    borderRadius: 8,
    marginBottom: 8,
  },
  text: {
    color:"white",
    fontSize: 15,
    margin: 3,
    
  },
  header:{
  color: "white",
  fontSize: 18,
  padding: 8
  }
});
