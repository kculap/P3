import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export function ProfileScreen({ route, navigation }) {

function handleHomePress(){
  navigation.navigate("Home")
}
return (
    <View style={styles.screen}>
      <Text style={styles.title}>Profile Screen</Text>
      <Button color="#e0b17e"
      title="Go to Home Screen"
      onPress={handleHomePress}
       />
       <Button color="#b8616d" title="Go to Settings Screen" onPress={() => navigation.navigate('Setting')} />
       <Button color="#6184b8" title="Go to About Screen" onPress={() => navigation.navigate('About')} />
    </View>
  );
  

}
const styles = StyleSheet.create({
  screen: {
    backgroundColor:"#fcedf9",
    flex: 1,
    alignContent: "center",
    justifyContent: "center",
    padding: 25,
    fontFamily:"cursive",
  },
  title: {
fontFamily: "italic",
fontSize:25,
textAlign: "center",
padding:15,
color: "#b8616d"

}
});
