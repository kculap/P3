import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export function HomeScreen({ route, navigation }) {

function handleSettingsPress(){
  navigation.navigate("Settings")
}

  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Home Screen</Text>
      <View style={styles.button}>
      <Button color="#b8616d"
      title="Go to Settings Screen" 
      onPress={() => navigation.navigate('Setting')}
      />
      <Button color="#6184b8" title="Go to About Screen" onPress={() => navigation.navigate('About')} />
       <Button color="#61b88f"title="Go to Profile Screen" onPress={() => navigation.navigate('Profile')} />
       </View>
    </View>
  );

}


const styles = StyleSheet.create({
  screen: {
    backgroundColor:"#fcedf9",
    flex: 1,
    alignContent: "center",
    justifyContent: "center",
    padding: 25,
    fontFamily:"italic",
  },

title: {
fontFamily: "italic",
fontSize:25,
textAlign: "center",
padding:15,
color: "#b8616d"

}
 
  
});
