import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  Alert,
  TouchableOpacity,
} from "react-native";

export default function App() {
  return (
    
    <View style={styles.container}>
      
          
      <View style={styles.jumbotron}>

        <View style={styles.container}>
         
  <View style={styles.container}>
   <Image
        style={styles.tinyLogo}
        source={{
          uri: "https://cdn-icons-png.flaticon.com/512/4892/4892735.png",
          
        }}
        
      />  
<Text style={styles.title}>Personal Data</Text>
          <Text style={styles.subtitle}> <b> Name: </b>Katarina Ćulap  </Text>
          <Text style={styles.subtitle}> <b> Birth: </b>29.1.2000., Slavonski Brod  </Text>
          <Text style={styles.subtitle}> <b> Nationality: </b>Croatian </Text>
          <Text style={styles.subtitle}> <b> Gender: </b>Female </Text>

          
          
          <Text style={styles.title}>Education</Text>
          <Text style={styles.subtitle}> <b> Josip Juraj Strossmayer University in Osijek</b>  </Text>
          <Text style={styles.subtitle}>2018. - 2022. - univ. bacc. informatol. </Text>
          <Text style={styles.subtitle}> <b> Highschool education</b>  </Text>
          <Text style={styles.subtitle}>2014. - 2018. - Ekonomsko-birotehnička škola Slavonski Brod </Text>


        
<Text style={styles.title}>Skills</Text>
 <Text style={styles.subtitle}>► Computer skills </Text>
       <Text style={styles.subtitle}>► Java, html, css </Text>
      <Text style={styles.subtitle}>► Communication skills</Text>
      <Text style={styles.subtitle}>► Team work </Text>

      <Text style={styles.title}>Interests</Text>
 <Text style={styles.subtitle}>► Desing </Text>
       <Text style={styles.subtitle}>► Reading books </Text>
      <Text style={styles.subtitle}>► Cycling</Text>
      <Text style={styles.subtitle}>► Volleyball </Text>
        </View>
        </View>
        <View style={styles.container}>
         
          
     <Text style={styles.header}>Hey, I'm Katarina</Text>
          <Text style={styles.subtitleheader}>Student of Informatology and Information technology at Josip Juraj Strossmayer University in Osijek.</Text>
          
<Button style={styles.btn} title="My projects" onPress={() => Alert.alert("Button pressed")} />

     
      

      <Text style={styles.title}>Work experience</Text>
        <Text style={styles.subtitle}>► Agent u teleprodaji (July-October 2022.)</Text>
         <Text style={styles.subtitle}>Hrvatski telekom d.o.o.  </Text>
         <Text style={styles.subtitle}>► Servirka (June-October 2018.)</Text>
         <Text style={styles.subtitle}>Plava laguna d.o.o.  </Text>

      <Text style={styles.title}>Language</Text>
      <Text style={styles.subtitle}> <b> English </b>  </Text>
      <Text style={styles.subtitle}>    Reading  • • • •    </Text>
      <Text style={styles.subtitle}>    Writing  • • • •  </Text>
      <Text style={styles.subtitle}> <b> Germany  </b>  </Text>
      <Text style={styles.subtitle}>      Reading  • • •     </Text>
      <Text style={styles.subtitle}>      Writing  • • •    </Text>

<Text style={styles.title}>Contact</Text>
<Text style={styles.subtitle}> <b>Mob.:</b> 092148646  </Text>
<Text style={styles.subtitle}> <b>Email.:</b> kculap@ffos.hr  </Text>


     
      </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    backgroundColor: "#F2F4F4",
    margin:20,
  
    
  },
  
  title: {
    textAlign: "left",
    fontSize: 30,
    color: "#2471A3",
    fontFamily: "bold",
    fontWeight: 555,
    marginTop: 50,
    paddingBottom:20
    
  },
  jumbotron: {
    flexDirection: "row",
    padding: 50,
   textAlign: "center"
    
   
  
  },
  tinyLogo: {
    width: 180,
    height: 180,
    marginLeft:170,
    marginBottom: 65,
  
  
  },
 

  subtitle: {
    color: "black",
    fontFamily: "bold",
    fontSize: 15,
    textAlign: "left",
    padding:10
  },

header:{
  fontSize: 50,
  color: "#2471A3",
  fontFamily: "bold",
  textAlign:"left",
  paddingTop:80
  
},

subtitleheader:{
  fontSize:20,
  fontFamily: "bold",
  textAlign: "left",
  paddingBottom: 40

},
btn:{
alignItems: "center",

},


});
