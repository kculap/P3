import * as React from 'react';
import { 
   View,
  Text,
  FlatList,
  StyleSheet,
  Image,
  Button,
  TouchableOpacity,
 } from 'react-native';


export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.dateWrapper}>
       <Text style={styles.optionsItem}>Sign in</Text>
        <Text style={styles.label}>Stay updated on your professional world</Text>
      </View>

      <View style={styles.dateWrapper}>

        <View style={styles.emailWrapper}>
        <Text>Email or Phone</Text>
        </View>
      </View>

      <View style={styles.dateWrapper}>
        <View style={styles.emailWrapper}>
        <Text>Password</Text>
         <Text style={styles.show}>show</Text>
        </View>
    <Text style={styles.blue}>Forgot password?</Text>
          
        
      </View>

      <TouchableOpacity style={styles.gameCommentsJumbotron}>
        <Text style={styles.buttonText}>Sign in</Text>
      </TouchableOpacity>
       <View style={styles.dateWrapper}>
       
        <Text style={styles.option}>or</Text>
      </View> 
       <TouchableOpacity style={styles.secButton}>
     
        <Text style={styles.secButtonText}> <Image
          source={{
            uri: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg",
          }}
          style={{width: 18, height:21 }}
        />  Sign in with Apple</Text>
        
      </TouchableOpacity>
         <View style={styles.dateWrapper}>
        <Text style={styles.center}>New to Linkedln?<Text style={styles.blue}> Join now</Text></Text>
      </View>   
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingTop: 20
  },
  gameCommentsJumbotron: {
    marginTop: 30,
    padding: 12,
    marginHorizontal: 20,
    borderRadius: 80,
    backgroundColor: "#3370d4"
  },
  buttonText:{
    textAlign: "center",
    fontSize: 16,
    color: "white",
    fontWeight: 500,
  },
  
  optionsItem: {
    fontSize: 35,
    fontWeight: 700,
  },
  dateWrapper: {
    paddingTop: 25,
    paddingLeft: 20
  },
  label:{
    fontSize: 15,
    paddingBottom: 10
  },

  emailWrapper:{
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginRight: 20,
    padding: 12,
    borderWidth: 2.4,
    borderRadius: 5,
    borderColor: "grey",
    
  },
  show: {
    color: "#3370d4",
    fontWeight: "bold",
  },

  blue: {
    color: "#3370d4",
    fontWeight: "bold",
    paddingTop: 15

  },

  center:{
    textAlign: "center",

  },

  option:{
    borderBottomWidth: 1,
    textAlign: "center",
    fontSize:15,
    borderColor: "grey",
    color: "grey"
  },

  secButtonText:{
    textAlign: "center",
    fontSize: 16,
    color: "grey",
    fontWeight: 500,
  },

  secButton:{
    marginTop: 30,
    padding: 12,
    marginHorizontal: 20,
    borderWidth: 2.4,
    borderRadius: 80,
    borderColor: "grey",
  }
 
});
