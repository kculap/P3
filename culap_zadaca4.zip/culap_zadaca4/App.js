import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  ScrollView,
  FlatList,
  Image
} from 'react-native';

import GoalItem from './components/GoalItem';
import GoalInput from './components/GoalInput';

    

export default function App() {
  const [courseGoals, setCourseGoals] = useState([]);
  const addGoalHandler = goalTitle => {
    setCourseGoals(currentGoals => [
      ...currentGoals,
      { id: Math.random().toString(), value: goalTitle }
    ]);
  };

    

  return (
    
    <View style={styles.screen}>
    
    <Text style={styles.title}>COURSE GOALS</Text>
     <Image style={styles.img}
        source={{
          uri: "https://img.icons8.com/external-smashingstocks-flat-smashing-stocks/512/external-Progress-investment-smashingstocks-flat-smashing-stocks.png",
        }}
      />
    <Text style={styles.paragraph}>
    
        Input your Course Goals:
      </Text>
      <GoalInput onAddGoal={addGoalHandler}/>
      <FlatList
        keyExtractor={(item, index) => item.id}
        data={courseGoals}
        renderItem={itemData => <GoalItem title={itemData.item.value} />}
      />
    </View>
  );
  
}

   

const styles = StyleSheet.create({
  screen: {
    padding: 40,
    alignItems: "center",
    backgroundColor: "#c6e1f7"

  },

  title: {
      textAlign: "center",
      fontFamily: "bold",
      fontSize: 25,
      padding: 20
  },

  paragraph: {
    padding: 10,
    fontFamily: "bold",
  },

  img:{
    width: 80,
    height: 80,


  }


  
});