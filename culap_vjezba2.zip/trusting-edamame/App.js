import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  Alert,
  TouchableOpacity,
} from "react-native";

export default function App() {
  return (
    // View, text Component
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Test app</Text>
      </View>

      {/* Flexbox layout */}
      <View style={styles.jumbotron}>
        <View style={styles.container}>
          <Text style={styles.subtitle}>Left</Text>
          <Image
        style={styles.tinyLogo}
        source={{
          uri: "https://reactnative.dev/img/tiny_logo.png",
        }}
      />
        </View>
        <View style={styles.container}>
          <Text style={styles.subtitle}>Right</Text>
          <Image
        style={styles.tinyLogo}
        source={{
          uri: "https://reactnative.dev/img/tiny_logo.png",
        }}
      />
        </View>
      </View>

      {/* Image component */}
      
      

      {/* button component */}
      <Button style={styles.button} title="Button" onPress={() => Alert.alert("Button pressed")} />

      {/* touchable opacity component */}
      <TouchableOpacity
        style={styles.resolvedContainerStyle}
        onPress={() => Alert.alert("TouchableOpacity pressed")}
      >
        <Text style={styles.textStyle}>Touchable opacity</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    backgroundColor: "black",
  },
  header: {
    borderBottomWidth: 2,
    padding: 10,
    paddingBottom: 2
  },
  title: {
    textAlign: "center",
    fontSize: 40,
    color: "lightblue",
    fontFamily: "bold",
    fontWeight: 555
    
  },
  jumbotron: {
    flexDirection: "row",
    margin: 20,
  },
  tinyLogo: {
    padding: 70,
    width: 120,
    height: 120,
  
  },
  resolvedContainerStyle: {
    margin: 20,
    backgroundColor: "grey",
    padding: 20,
    textAlign: "center",
    borderRadius: 100,
    

  },
  textStyle: {
    fontSize: 20,
    color: "black",
  },

  subtitle: {
    color: "white",
    fontFamily: "bold",
    fontSize: 25,
    textAlign: "center",
    padding:10
  },


});
